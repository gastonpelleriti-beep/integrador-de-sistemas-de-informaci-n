CREATE DATABASE IF NOT EXISTS sistema_socios
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE sistema_socios;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  rol ENUM('admin', 'operador') NOT NULL DEFAULT 'operador',
  creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS socios (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(60) NOT NULL,
  apellido VARCHAR(60) NOT NULL,
  dni VARCHAR(20) NOT NULL UNIQUE,
  telefono VARCHAR(25),
  correo VARCHAR(120),
  fecha_alta DATE NOT NULL,
  estado ENUM('activo', 'inactivo') NOT NULL DEFAULT 'activo',
  creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_socios_apellido (apellido),
  INDEX idx_socios_estado (estado)
);

-- El resultado completo se guarda cifrado como un bloque opaco.
-- No se almacena aquí el contenido legible de la consulta.
CREATE TABLE IF NOT EXISTS consultas_guardadas (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT UNSIGNED NOT NULL,
  titulo VARCHAR(120) NOT NULL,
  algoritmo VARCHAR(30) NOT NULL DEFAULT 'aes-256-gcm',
  iv CHAR(24) NOT NULL,
  auth_tag CHAR(32) NOT NULL,
  contenido_cifrado LONGTEXT NOT NULL,
  creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_consultas_usuario
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    ON DELETE RESTRICT,
  INDEX idx_consultas_usuario_fecha (usuario_id, creado_en)
);
