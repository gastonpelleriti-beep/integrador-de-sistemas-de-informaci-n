require('dotenv').config();
const bcrypt = require('bcrypt');
const pool = require('./config/database');

(async () => {
  try {
    const nombre = process.env.ADMIN_NAME || 'Administrador';
    const email = String(process.env.ADMIN_EMAIL || '').trim().toLowerCase();
    const password = process.env.ADMIN_PASSWORD || '';
    if (!email || password.length < 12) {
      throw new Error('Configurá ADMIN_EMAIL y una ADMIN_PASSWORD de al menos 12 caracteres en .env.');
    }
    const [existing] = await pool.execute('SELECT id FROM usuarios WHERE email = ?', [email]);
    if (existing.length) {
      console.log('Ese administrador ya existe. No se realizaron cambios.');
      return;
    }
    const hash = await bcrypt.hash(password, 12);
    await pool.execute(
      'INSERT INTO usuarios (nombre, email, password_hash, rol) VALUES (?, ?, ?, ?)',
      [nombre, email, hash, 'admin']
    );
    console.log(`Administrador creado: ${email}`);
  } catch (error) {
    console.error('No se pudo crear el administrador:', error.message);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
})();
