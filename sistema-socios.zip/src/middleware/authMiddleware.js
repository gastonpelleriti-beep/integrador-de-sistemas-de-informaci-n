function requireAuth(req, res, next) {
  if (!req.session.user) {
    return res.status(401).json({ error: 'Tenés que iniciar sesión.' });
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!req.session.user || req.session.user.rol !== 'admin') {
    return res.status(403).json({ error: 'No tenés permisos para realizar esta acción.' });
  }
  next();
}

module.exports = { requireAuth, requireAdmin };
