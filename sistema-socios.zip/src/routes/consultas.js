const express = require('express');
const pool = require('../config/database');
const { requireAuth } = require('../middleware/authMiddleware');
const { encryptObject, decryptObject } = require('../utils/encryption');
const router = express.Router();

router.use(requireAuth);

// Guarda una copia del resultado de una consulta ya ejecutada por el sistema.
// Se cifra el JSON completo antes de enviarlo a MySQL.
router.post('/', async (req, res, next) => {
  try {
    const titulo = String(req.body.titulo || '').trim();
    const resultado = req.body.resultado;
    if (!titulo || titulo.length > 120 || resultado === undefined) {
      return res.status(400).json({ error: 'Indicá un título y un resultado para guardar.' });
    }
    const json = JSON.stringify(resultado);
    if (Buffer.byteLength(json, 'utf8') > 500000) {
      return res.status(413).json({ error: 'El resultado es demasiado grande (máximo 500 KB).' });
    }

    const encrypted = encryptObject(resultado);
    const [insert] = await pool.execute(
      `INSERT INTO consultas_guardadas
       (usuario_id, titulo, algoritmo, iv, auth_tag, contenido_cifrado)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [req.session.user.id, titulo, encrypted.algorithm, encrypted.iv,
       encrypted.authTag, encrypted.content]
    );
    res.status(201).json({ message: 'Resultado guardado cifrado.', id: insert.insertId });
  } catch (error) {
    next(error);
  }
});

router.get('/', async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT id, titulo, algoritmo, creado_en
       FROM consultas_guardadas WHERE usuario_id = ? ORDER BY creado_en DESC LIMIT 100`,
      [req.session.user.id]
    );
    res.json({ consultas: rows });
  } catch (error) {
    next(error);
  }
});

router.get('/:id', async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ error: 'ID inválido.' });
    const [rows] = await pool.execute(
      `SELECT id, titulo, algoritmo, iv, auth_tag, contenido_cifrado
       FROM consultas_guardadas WHERE id = ? AND usuario_id = ? LIMIT 1`,
      [id, req.session.user.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Consulta no encontrada.' });
    const row = rows[0];
    const resultado = decryptObject({
      iv: row.iv,
      authTag: row.auth_tag,
      content: row.contenido_cifrado
    });
    res.json({ id: row.id, titulo: row.titulo, resultado });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
