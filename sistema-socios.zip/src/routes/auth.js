const express = require('express');
const bcrypt = require('bcrypt');
const pool = require('../config/database');
const router = express.Router();

router.post('/login', async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (!email || !password || email.length > 120 || password.length > 200) {
      return res.status(400).json({ error: 'Completá correo y contraseña.' });
    }

    const [rows] = await pool.execute(
      'SELECT id, nombre, email, password_hash, rol FROM usuarios WHERE email = ? LIMIT 1',
      [email]
    );
    if (!rows.length || !(await bcrypt.compare(password, rows[0].password_hash))) {
      return res.status(401).json({ error: 'Correo o contraseña incorrectos.' });
    }

    req.session.regenerate((err) => {
      if (err) return next(err);
      req.session.user = {
        id: rows[0].id,
        nombre: rows[0].nombre,
        email: rows[0].email,
        rol: rows[0].rol
      };
      req.session.save((saveErr) => {
        if (saveErr) return next(saveErr);
        res.json({ user: req.session.user });
      });
    });
  } catch (error) {
    next(error);
  }
});

router.get('/me', (req, res) => {
  res.json({ user: req.session.user || null });
});

router.post('/logout', (req, res, next) => {
  req.session.destroy((err) => {
    if (err) return next(err);
    res.clearCookie('sid');
    res.json({ message: 'Sesión cerrada.' });
  });
});

module.exports = router;
