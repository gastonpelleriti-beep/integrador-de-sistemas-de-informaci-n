const express = require('express');
const pool = require('../config/database');
const { requireAuth, requireAdmin } = require('../middleware/authMiddleware');
const router = express.Router();

router.use(requireAuth);

function validateSocio(body) {
  const nombre = String(body.nombre || '').trim();
  const apellido = String(body.apellido || '').trim();
  const dni = String(body.dni || '').trim();
  const telefono = String(body.telefono || '').trim();
  const correo = String(body.correo || '').trim();
  const estado = body.estado === 'inactivo' ? 'inactivo' : 'activo';
  const fechaAlta = String(body.fecha_alta || '').trim();

  if (!nombre || !apellido || !dni || !fechaAlta) {
    return { error: 'Nombre, apellido, DNI y fecha de alta son obligatorios.' };
  }
  if (nombre.length > 60 || apellido.length > 60 || dni.length > 20 ||
      telefono.length > 25 || correo.length > 120) {
    return { error: 'Uno o más campos superan el largo permitido.' };
  }
  if (correo && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo)) {
    return { error: 'El correo no tiene un formato válido.' };
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(fechaAlta)) {
    return { error: 'La fecha debe tener formato AAAA-MM-DD.' };
  }
  return { value: { nombre, apellido, dni, telefono, correo, estado, fechaAlta } };
}

router.get('/', async (req, res, next) => {
  try {
    const q = String(req.query.q || '').trim().slice(0, 80);
    const estado = String(req.query.estado || '').trim();
    let sql = `SELECT id, nombre, apellido, dni, telefono, correo,
                      DATE_FORMAT(fecha_alta, '%Y-%m-%d') AS fecha_alta,
                      estado, creado_en
               FROM socios WHERE 1=1`;
    const params = [];
    if (q) {
      sql += ' AND (nombre LIKE ? OR apellido LIKE ? OR dni LIKE ?)';
      params.push(`%${q}%`, `%${q}%`, `%${q}%`);
    }
    if (estado === 'activo' || estado === 'inactivo') {
      sql += ' AND estado = ?';
      params.push(estado);
    }
    sql += ' ORDER BY apellido, nombre LIMIT 500';
    const [rows] = await pool.execute(sql, params);
    res.json({ socios: rows });
  } catch (error) {
    next(error);
  }
});

router.post('/', async (req, res, next) => {
  try {
    const checked = validateSocio(req.body);
    if (checked.error) return res.status(400).json({ error: checked.error });
    const s = checked.value;
    const [result] = await pool.execute(
      `INSERT INTO socios (nombre, apellido, dni, telefono, correo, fecha_alta, estado)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [s.nombre, s.apellido, s.dni, s.telefono || null, s.correo || null, s.fechaAlta, s.estado]
    );
    res.status(201).json({ message: 'Socio registrado.', id: result.insertId });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Ya existe un socio con ese DNI.' });
    next(error);
  }
});

router.put('/:id', async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ error: 'ID inválido.' });
    const checked = validateSocio(req.body);
    if (checked.error) return res.status(400).json({ error: checked.error });
    const s = checked.value;
    const [result] = await pool.execute(
      `UPDATE socios SET nombre=?, apellido=?, dni=?, telefono=?, correo=?,
       fecha_alta=?, estado=? WHERE id=?`,
      [s.nombre, s.apellido, s.dni, s.telefono || null, s.correo || null, s.fechaAlta, s.estado, id]
    );
    if (!result.affectedRows) return res.status(404).json({ error: 'Socio no encontrado.' });
    res.json({ message: 'Socio actualizado.' });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Ese DNI ya pertenece a otro socio.' });
    next(error);
  }
});

router.delete('/:id', requireAdmin, async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ error: 'ID inválido.' });
    const [result] = await pool.execute('DELETE FROM socios WHERE id = ?', [id]);
    if (!result.affectedRows) return res.status(404).json({ error: 'Socio no encontrado.' });
    res.json({ message: 'Socio eliminado.' });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
