const $ = (selector) => document.querySelector(selector);
const loginPanel = $('#loginPanel');
const appPanel = $('#appPanel');
let currentSocios = [];
let currentUser = null;

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'No se pudo completar la operación.');
  return data;
}
function showMessage(text, isError = false) {
  const el = $('#message');
  el.textContent = text;
  el.classList.toggle('error', isError);
}
function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[c]));
}
function showApp(user) {
  currentUser = user;
  loginPanel.classList.add('hidden');
  appPanel.classList.remove('hidden');
  $('#logoutBtn').classList.remove('hidden');
  $('#welcomeText').textContent = `Sesión iniciada: ${user.nombre}`;
  $('#roleText').textContent = user.rol === 'admin' ? 'Administrador' : 'Operador';
  loadSocios();
  loadSavedQueries();
}
async function checkSession() {
  try {
    const data = await api('/api/auth/me');
    if (data.user) showApp(data.user);
  } catch (e) { showMessage(e.message, true); }
}
$('#loginForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  try {
    const data = await api('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: form.get('email'), password: form.get('password') })
    });
    event.currentTarget.reset();
    showMessage('');
    showApp(data.user);
  } catch (e) { showMessage(e.message, true); }
});
$('#logoutBtn').addEventListener('click', async () => {
  try {
    await api('/api/auth/logout', { method: 'POST', body: '{}' });
    currentUser = null;
    appPanel.classList.add('hidden');
    $('#logoutBtn').classList.add('hidden');
    loginPanel.classList.remove('hidden');
    showMessage('Sesión cerrada.');
  } catch (e) { showMessage(e.message, true); }
});

async function loadSocios() {
  try {
    const params = new URLSearchParams();
    if ($('#searchInput').value.trim()) params.set('q', $('#searchInput').value.trim());
    if ($('#statusFilter').value) params.set('estado', $('#statusFilter').value);
    const data = await api(`/api/socios?${params}`);
    currentSocios = data.socios;
    renderSocios();
  } catch (e) { showMessage(e.message, true); }
}
function renderSocios() {
  $('#totalSocios').textContent = currentSocios.length;
  $('#totalActivos').textContent = currentSocios.filter(s => s.estado === 'activo').length;
  $('#emptyMessage').classList.toggle('hidden', currentSocios.length > 0);
  $('#sociosBody').innerHTML = currentSocios.map(s => `
    <tr>
      <td><strong>${escapeHtml(s.apellido)}, ${escapeHtml(s.nombre)}</strong></td>
      <td>${escapeHtml(s.dni)}</td>
      <td>${escapeHtml(s.telefono || '—')}<br>${escapeHtml(s.correo || '')}</td>
      <td>${escapeHtml(s.fecha_alta)}</td>
      <td><span class="status ${s.estado}">${s.estado === 'activo' ? 'Activo' : 'Inactivo'}</span></td>
      <td><div class="actions">
        <button class="secondary" data-edit="${s.id}">Editar</button>
        ${currentUser.rol === 'admin' ? `<button class="danger" data-delete="${s.id}">Eliminar</button>` : ''}
      </div></td>
    </tr>`).join('');
}
$('#sociosBody').addEventListener('click', async (event) => {
  const editId = event.target.dataset.edit;
  const deleteId = event.target.dataset.delete;
  if (editId) {
    const s = currentSocios.find(item => item.id === Number(editId));
    if (!s) return;
    const form = $('#socioForm');
    for (const key of ['id','nombre','apellido','dni','telefono','correo','fecha_alta','estado']) {
      form.elements[key].value = key === 'id' ? s.id : (s[key] || '');
    }
    $('#formTitle').textContent = 'Modificar socio';
    $('#saveSocioBtn').textContent = 'Guardar cambios';
    $('#cancelEditBtn').classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  if (deleteId && confirm('¿Seguro que querés eliminar este socio?')) {
    try {
      await api(`/api/socios/${deleteId}`, { method: 'DELETE' });
      showMessage('Socio eliminado.');
      loadSocios();
    } catch (e) { showMessage(e.message, true); }
  }
});
$('#socioForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const values = Object.fromEntries(new FormData(form).entries());
  const id = values.id;
  delete values.id;
  try {
    await api(id ? `/api/socios/${id}` : '/api/socios', {
      method: id ? 'PUT' : 'POST',
      body: JSON.stringify(values)
    });
    resetSocioForm();
    showMessage(id ? 'Socio actualizado.' : 'Socio registrado.');
    await loadSocios();
  } catch (e) { showMessage(e.message, true); }
});
function resetSocioForm() {
  $('#socioForm').reset();
  $('#socioForm').elements.id.value = '';
  $('#formTitle').textContent = 'Cargar socio';
  $('#saveSocioBtn').textContent = 'Guardar socio';
  $('#cancelEditBtn').classList.add('hidden');
  $('#socioForm').elements.fecha_alta.value = new Date().toISOString().slice(0,10);
}
$('#cancelEditBtn').addEventListener('click', resetSocioForm);
$('#searchBtn').addEventListener('click', loadSocios);
$('#refreshBtn').addEventListener('click', () => { $('#searchInput').value=''; $('#statusFilter').value=''; loadSocios(); });
$('#searchInput').addEventListener('keydown', e => { if (e.key === 'Enter') loadSocios(); });

$('#saveQueryBtn').addEventListener('click', async () => {
  const titulo = $('#queryTitle').value.trim();
  if (!titulo) return showMessage('Escribí un título para el resultado.', true);
  try {
    const data = await api('/api/consultas', {
      method: 'POST',
      body: JSON.stringify({ titulo, resultado: currentSocios })
    });
    $('#queryTitle').value = '';
    showMessage(`Resultado guardado cifrado (registro ${data.id}).`);
    loadSavedQueries();
  } catch (e) { showMessage(e.message, true); }
});
async function loadSavedQueries() {
  try {
    const data = await api('/api/consultas');
    $('#savedQueries').innerHTML = data.consultas.map(q =>
      `<li>${escapeHtml(q.titulo)} <small>(${new Date(q.creado_en).toLocaleString('es-AR')})</small>
       <button class="secondary" data-open-query="${q.id}">Abrir</button></li>`
    ).join('') || '<li class="muted">Todavía no guardaste resultados.</li>';
  } catch (e) { showMessage(e.message, true); }
}
$('#savedQueries').addEventListener('click', async (event) => {
  const id = event.target.dataset.openQuery;
  if (!id) return;
  try {
    const data = await api(`/api/consultas/${id}`);
    const w = window.open('', '_blank');
    if (!w) return showMessage('El navegador bloqueó la ventana emergente.', true);
    const safe = escapeHtml(JSON.stringify(data.resultado, null, 2));
    w.document.write(`<title>${escapeHtml(data.titulo)}</title><pre style="font:14px monospace;white-space:pre-wrap;padding:20px">${safe}</pre>`);
    w.document.close();
  } catch (e) { showMessage(e.message, true); }
});

resetSocioForm();
checkSession();
